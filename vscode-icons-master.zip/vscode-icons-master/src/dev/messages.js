exports.messages ={
  admin: 'Run VS Code with admin privileges so the changes can be applied.',
  enabled:'Icons enabled. Restart to take effect.',
  disabled:'Icons disabled. Restart to take effect.',
  already_disabled:'Icons already disabled.',
  smthingwrong: 'Something went wrong: ',
  restartIde: 'Restart Visual Studio Code'
};