/// <reference path="../node_modules/vscode/typings/index.d.ts" />
